package com.example.thirapp.thirapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.EditText;
import android.util.Log;
import android.widget.Toast;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
  public void process(View view)
  {
      Log.d("debug","press button");
      Log.i("information","press button");
      Log.e("Error","press button");

      EditText editText = (EditText) findViewById(R.id.editText);

      String snumber = editText.getText().toString();
      int num = Integer.parseInt(snumber);

      Random rand = new Random();

      int n = rand.nextInt(10) + 1;

      if(num < n)
      {
          Toast.makeText(getApplicationContext(),"Your number is less then Guess Number",Toast.LENGTH_SHORT).show();
      }
      else if(num > n){
          Toast.makeText(getApplication(),"Your number is greater then Guess Number",Toast.LENGTH_SHORT).show();

      }
      else {
          Toast.makeText(getApplicationContext(),"Congrtz You Win",Toast.LENGTH_SHORT).show();
      }

  }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
